# Infodeck Flow（IFX）

Infodeck Flow（IFX）は、CSV / Excel データを自動で結合・整形・集計し、レポートとして出力する業務効率化ツールのコアエンジンです。

## 実行方法
pip install -r requirements.txt
python src/main.py
